import React, { Component } from 'react';
//import logo from './logo.svg';
import './App.css';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-alpine.css';
import ButtonCellRenderer from './ButtonCellRenderer';
import NewTransaction from './NewTransaction'
class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      inc :0,
      showNewTran:false,
      row: {id:0,name:'',description:'',transactionDate:'',amount:''},
      columnDefs: [
        {
          headerName: "ID", field: "id"
        },{
        headerName: "Name", field: "name"
      }, {
        headerName: "Description", field: "description"
      }, {
        headerName: "Transaction Date", field: "transactionDate"
      }, {
        headerName: "Amount", field: "amount"
      }
    ,  {
      
      cellRenderer: 'buttonCellRenderer',
      cellRendererParams: {
        clicked: this.toggleNewTran 
      },
      minWidth: 150,
    }],
      rowData: [],
      frameworkComponents: {
        buttonCellRenderer: ButtonCellRenderer,
      }
      
    };
    
 

  }
  toggleNewTran = () => {
    const doesShow = this.state.showNewTran;
    this.setState( { showNewTran: !doesShow } );
  }
  onChangeDescription=(event)=>{
    const rowTemp = this.state.row;
    rowTemp.description=event.target.value;
    this.setState({row:rowTemp});
  }
  onChangeTranDate=(event)=>{
    const rowTemp = this.state.row;
    rowTemp.transactionDate=event.target.value;
    this.setState({row:rowTemp});
  }
  onChangeAmount=(event)=>{
    const rowTemp = this.state.row;
    rowTemp.amount=event.target.value;
    this.setState({row:rowTemp});
  }
  onChangeName=(event)=>{
    const rowTemp = this.state.row;
    rowTemp.name=event.target.value;
    this.setState({row:rowTemp});
  }
  handleAdd=()=>{
    const rowTemp = this.state.row;
    const rowDataTemp=[...this.state.rowData];
    let index=this.state.inc;
    if(rowDataTemp.length>index){
      index++;
    }
    rowTemp.id=index;
    rowDataTemp.push(rowTemp)
    this.setState({rowData:rowDataTemp,inc:index});
  }

  render() {
    let newTranDiv=null;
   
    if(this.state.showNewTran){
      newTranDiv=(
       
        <div>
          <NewTransaction changeName={(event)=>this.onChangeName(event)} 
          changeDescription={(event)=>this.onChangeDescription(event)} 
          changeTranDate={(event)=>this.onChangeTranDate(event)} 
          changeAmount={(event)=>this.onChangeAmount(event)} 
          addRow={this.handleAdd}
          name={this.state.row.name}
          description={this.state.row.description} 
          transactionDate={this.state.row.transactionDate}
          amount={this.state.row.amount}
           ></NewTransaction>
        </div>
      )
    }
    return (
      

      <div
        className="ag-theme-alpine"
        style={{

        height: '300px',
        width: '500px' }}
      >
        <button onClick={this.toggleNewTran}>New Transaction</button>
        {newTranDiv}
        <AgGridReact
          columnDefs={this.state.columnDefs}
          rowData={this.state.rowData}
          frameworkComponents={this.state.frameworkComponents}>
        </AgGridReact>
      </div>
    );
  }
}

export default App;