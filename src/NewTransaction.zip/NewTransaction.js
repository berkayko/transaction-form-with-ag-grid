import React from 'react';


const NewTransaction = ( props ) => {
    return (
        <div >
            <header>New Transaction</header>
            <input onChange={props.changeName} value={props.name} />
            <input onChange={props.changeDescription} value={props.description} />
            <input onChange={props.changeTranDate} value={props.transactionDate} />
            <input onChange={props.changeAmount} value={props.amount} />
            <button onClick={props.addRow}>
                Add
            </button>
            <button>close</button>
        </div>
    )
};

export default NewTransaction;